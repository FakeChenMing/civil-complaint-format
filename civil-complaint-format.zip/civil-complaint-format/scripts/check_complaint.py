#!/usr/bin/env python3
"""Read-only, limited structural audit. Does not validate identity, evidence or law."""
import argparse,json,re
from docx import Document
from docx.oxml.ns import qn

def audit(path, template=False):
 d=Document(path); errors=[]; warnings=[]; texts=[p.text.strip() for p in d.paragraphs]; alltext='\n'.join(texts)
 def error(i,s):errors.append(f'第{i+1}段：{s}')
 def value(run,p,tag,attr=None):
  props=[run._r.rPr]
  if run.style is not None:props.append(run.style.element.find(qn('w:rPr')))
  style=p.style
  while style is not None:
   props.append(style.element.find(qn('w:rPr')));style=style.base_style
  for rp in props:
   if rp is None:continue
   e=rp.find(qn('w:'+tag))
   if e is not None:
    v=e.get(qn('w:'+attr)) if attr else e.get(qn('w:val'),'1')
    if v is not None:return v
  return None
 for label in ['诉讼请求：','事实与理由：']:
  found=[(i,p) for i,p in enumerate(d.paragraphs) if p.text.strip()==label]
  if len(found)!=1:errors.append(f'{label}应恰好一段，实际{len(found)}段')
  for i,p in found:
   for r in p.runs:
    if not r.text.strip():continue
    if value(r,p,'rFonts','eastAsia')!='黑体':error(i,label+'未使用黑体');break
   for r in p.runs:
    if r.text.strip() and value(r,p,'b') not in ('1','true','on'):error(i,label+'未加粗');break
   for r in p.runs:
    if r.text.strip() and value(r,p,'sz')!='28':error(i,label+'不是四号14pt');break
 for i,t in enumerate(texts):
  if re.search(r'被告[一二三四五六七八九十0-9]|第[一二三四五六七八九十0-9]+被告',t):error(i,'出现编号被告称谓')
  if t.startswith('法定代表人：'):
   if not re.search(r'法定代表人：[^，。]+，职务：[^。]+',t):error(i,'法定代表人姓名或职务未按固定格式填写')
  if t.startswith(('原告：','被告：')) and '统一社会信用代码' in t:
   if i+1>=len(texts) or not texts[i+1].startswith('法定代表人：'):error(i,'组织主体未紧接法定代表人及职务段；非法人组织请人工核对负责人类型')
  if t.startswith('被告：') and '公民身份号码' in t:
   # Explicit placeholders are permitted only when validating the reusable master.
   if not template:
    birth=re.search(r'\d{4}年\d{1,2}月\d{1,2}日出生',t);sex=re.search(r'，[男女]，',t);addr=re.search(r'，(?:住所地|住)',t);idpos=t.find('公民身份号码')
    if not birth or not sex or not addr or not (sex.start()<birth.start()<addr.start()<idpos):error(i,'自然人信息须依姓名、性别、出生日期、住所、公民身份号码排序')
  if not template and re.search(r'〔[^〕]+〕|【待核[^】]*】|\bTODO\b',t):error(i,'仍有未填槽位或待核字段，不是完整定稿')
 start=next((i for i,t in enumerate(texts) if t=='事实与理由：'),len(texts))
 for i in range(start+1,len(texts)):
  t=texts[i]
  if t.startswith('因此') or t=='此致':break
  if re.search(r'双方|被告[，。与向已应未后]|\b其\b',t):warnings.append(f'第{i+1}段：检查模糊主体；须明确公司名称／简称或自然人姓名')
  if any(s in t for s in ['按照实际开票金额主张','未开票期间按','暂按最后','暂按发票','推算取回','本次按开票']):error(i,'事实理由混入内部核算／推算口径')
  if ('调价' in t or '调整租金' in t) and not re.search(r'自?\d{4}年\d{1,2}月\d{1,2}日.*?(?:调整|月租金).*?\d+(?:\.\d+)?元',t) and not template:warnings.append(f'第{i+1}段：调价需人工核对主体、生效日、调整金额及对象是否齐备')
 return {'errors':errors,'warnings':warnings,'manual_review_required':['职务和身份来源真实性','全体关键履行变更是否完整','简称与每个行为主体是否唯一','证据及法源支撑','每页渲染检查'],'structural_checks_passed':not errors}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('docx');p.add_argument('--template',action='store_true');a=p.parse_args();r=audit(a.docx,a.template);print(json.dumps(r,ensure_ascii=False,indent=2));raise SystemExit(0 if r['structural_checks_passed'] else 1)
